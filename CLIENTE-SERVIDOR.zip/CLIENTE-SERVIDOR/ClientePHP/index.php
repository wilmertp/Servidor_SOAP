<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //Crear el Cliente para acceder a los metodos del servicio
        $cliente = new SoapClient('http://localhost:8080/ServidorWeb_SOAP/WSOperaciones?WSDL');
        
        //Utilizar metodo
        $resultado_pago = $cliente -> ProcesarPago([
            "total" => 1000,
            "pago" => 100
        ]) -> return;
        
        if($resultado_pago >= 0){
            echo "Pago Realizado, su vuelto es $resultado_pago";
        }
        else{
            echo 'dinero Insuficiente';
        }
        
        ?>
    </body>
</html>
