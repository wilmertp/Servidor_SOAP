/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package ws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author damian
 */
@WebService(serviceName = "WSOperaciones")
public class WSOperaciones {

    /**
     * Web service operation
     * @param usuario
     * @param password
     * @return 
     */
    @WebMethod(operationName = "Login")
    public Boolean Login(@WebParam(name = "usuario") String usuario, @WebParam(name = "password") String password) {
        
        return usuario.equals("Wilmer") && password.equals("123");
    }

    /**
     * Web service operation
     * @param total
     * @param pago
     * @return 
     */
    @WebMethod(operationName = "ProcesarPago")
    public int PorcesarPago(@WebParam(name = "total") int total, @WebParam(name = "pago") int pago) {
        
        if(pago >= total){
            return pago - total;
        }
        else{
            return -1;
        }
    }

}
